<?php
namespace MyFisdap;

use Zend\Router\Http\Literal;
use Zend\Router\Http\Segment;
use Doctrine\ORM\Mapping\Driver\AnnotationDriver;

return [
    'router' => [
        'routes' => [
            'my-fisdap' => [
                'type' => Literal::class,
                'options' => [
                    'route'    => '/my-fisdap',
                    'defaults' => [
                        'controller' => Controller\MyFisdapController::class,
                        'action'     => 'myFisdap',
                    ],
                ],
            ],
         ],
    ],
   
    'view_manager' => [
        'template_path_stack' => [
            __DIR__ . '/../view',
        ],
    ],
    'doctrine' => [
        'driver' => [
            __NAMESPACE__ . '_driver' => [
                'class' => AnnotationDriver::class,
                'cache' => 'array',
                'paths' => [__DIR__ . '/../src/Entity']
            ],
            'orm_default' => [
                'drivers' => [
                    __NAMESPACE__ . '\Entity' => __NAMESPACE__ . '_driver'
                ]
            ]
        ]
    ],
];
